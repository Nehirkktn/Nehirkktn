<p align="center">
  <img src="./header.svg" width="100%" alt="Terminal window. whoami: Nehir Kökten, Software Engineering student, year 2, Fırat University. Focus: games, security tooling, web platforms. Status: co-founder at DuckingCore, Microsoft Student Ambassador." />
</p>

<p align="center">
  <a href="https://www.linkedin.com/in/nehir-k%C3%B6kten-561a26377"><img src="https://img.shields.io/badge/LinkedIn-0D0D0D?style=for-the-badge&logo=linkedin&logoColor=CC1F1F" alt="LinkedIn" /></a>
  <a href="https://duckingcore.com.tr"><img src="https://img.shields.io/badge/duckingcore.com.tr-0D0D0D?style=for-the-badge&logo=firebase&logoColor=CC1F1F" alt="duckingcore.com.tr" /></a>
  <a href="mailto:duckingcoregames@gmail.com"><img src="https://img.shields.io/badge/Email-0D0D0D?style=for-the-badge&logo=gmail&logoColor=CC1F1F" alt="Email" /></a>
</p>

<p align="center"><i>I learn fastest by shipping. Everything below links to something real.</i></p>

<br>

<p align="center">
  <a href="https://github.com/Nehirkktn/penetration-testing-tool"><img src="./card-siber.svg" width="49%" alt="Siber Savaşçılar: OWASP Top 10 security scanner. 394 tests, 72 of 127 commits, 8 scan modules. Project lead of a 5-person team." /></a>
  <a href="https://duckingcore.com.tr"><img src="./card-platform.svg" width="49%" alt="DuckingCore Platform: studio operations panel with role-based permissions, push notifications and TR/EN i18n." /></a>
  <a href="https://github.com/Nehirkktn/Astro-Cats"><img src="./card-astro.svg" width="49%" alt="Astro Cats: neon colour-sort puzzle game in Python and Pygame." /></a>
  <img src="./card-kehanet.svg" width="49%" alt="Kehanet: PC game in development with Unity and C#, procedural hex map, 10-person team." />
</p>

<p align="center">
  <img src="./astro-cats-demo.gif" width="440" alt="Astro Cats gameplay: coloured alien blocks are moved between tubes until each tube holds one colour." />
  <br><sub>Astro Cats, recorded straight from the repo's code</sub>
</p>

<br>

<p align="center">
  <img src="https://img.shields.io/badge/Python-161616?style=flat-square&logo=python&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/Flask-161616?style=flat-square&logo=flask&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/Docker-161616?style=flat-square&logo=docker&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/SQLite-161616?style=flat-square&logo=sqlite&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/JavaScript-161616?style=flat-square&logo=javascript&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/Firebase-161616?style=flat-square&logo=firebase&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/Pygame-161616?style=flat-square&logo=python&logoColor=CC1F1F" />
  <img src="https://img.shields.io/badge/Unity_·_C%23-in_progress-161616?style=flat-square&logo=unity&logoColor=CC1F1F&labelColor=161616&color=3D0000" />
</p>

```text
$ git log --oneline nehir
2026-09  joined Microsoft Student Ambassadors
2026     launched duckingcore.com.tr
2026     led Siber Savaşçılar — 127 commits, 394 tests, shipped
2026     co-founded DuckingCore, grew the team to 10
2025     started Software Engineering @ Fırat University
```

<p align="center">
  <b>Next →</b> bringing hands-on build sessions to Fırat University as a Microsoft Student Ambassador.<br>
  <sub>Running a student community? <a href="mailto:duckingcoregames@gmail.com">Let's build something.</a></sub>
</p>
